import zlib, struct, math, random, os
OUT = "src/main/resources/assets/cosmicfx/textures/particle"
def png(path, w, h, f):
    rows = []
    for y in range(h):
        row = bytearray([0])
        for x in range(w):
            a = max(0.0, min(1.0, f((x + 0.5) / w * 2 - 1, (y + 0.5) / h * 2 - 1)))
            row += bytes([255, 255, 255, int(a * 255)])
        rows.append(bytes(row))
    raw = b"".join(rows)
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    data = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) \
        + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
    open(os.path.join(OUT, path), "wb").write(data)

def glow(x, y):
    d = math.hypot(x, y)
    return max(0, 1 - d) ** 2.2 + (0.5 if d < 0.12 else 0)
def star(x, y):
    v = abs(x) ** 0.5 + abs(y) ** 0.5
    return max(0, 1 - v) ** 1.4 + glow(x, y) * 0.7
def ring(x, y):
    d = math.hypot(x, y)
    return math.exp(-((d - 0.72) / 0.09) ** 2) + 0.12 * max(0, 1 - d)
def shard(x, y):
    v = abs(x) * 2.6 + abs(y) * 0.95
    return max(0, 1 - v) ** 0.7
def spark(x, y):
    g = max(0, 1 - math.hypot(x, y)) ** 3
    l1 = math.exp(-(x / 0.07) ** 2) * max(0, 1 - abs(y))
    l2 = math.exp(-(y / 0.07) ** 2) * max(0, 1 - abs(x))
    return g + l1 * 0.9 + l2 * 0.9
png("glow.png", 32, 32, glow)
png("star.png", 32, 32, star)
png("ring.png", 32, 32, ring)
png("shard.png", 32, 32, shard)
png("spark.png", 32, 32, spark)
for k in range(4):
    rnd = random.Random(100 + k)
    blobs = [(rnd.uniform(-.5, .5), rnd.uniform(-.5, .5), rnd.uniform(.25, .5)) for _ in range(5)]
    def wisp(x, y, blobs=blobs):
        s = 0
        for bx, by, br in blobs:
            s += math.exp(-((x - bx) ** 2 + (y - by) ** 2) / (br * br * 0.5))
        edge = max(0, 1 - math.hypot(x, y)) ** 1.2
        return min(1, s * 0.55) * edge
    png("wisp_%d.png" % k, 32, 32, wisp)
print("textures ok")
