import struct, gzip, os, time, json

def s(v):
    b = v.encode("utf-8"); return struct.pack(">H", len(b)) + b
def B(v): return (1, struct.pack(">b", v))
def I(v): return (3, struct.pack(">i", v))
def L(v): return (4, struct.pack(">q", v))
def F(v): return (5, struct.pack(">f", v))
def S(v): return (8, s(v))
def C(d):
    body = b"".join(struct.pack("B", t) + s(k) + p for k, (t, p) in d.items()) + b"\x00"
    return (10, body)
def LST(items, typ):
    return (9, struct.pack("B", typ) + struct.pack(">i", len(items)) + b"".join(p for t, p in items))

def layer(block, h): return C({"block": S(block), "height": I(h)})

flat = C({"type": S("minecraft:flat"), "settings": C({
    "biome": S("minecraft:plains"), "features": B(0), "lakes": B(0),
    "layers": LST([layer("minecraft:bedrock", 1), layer("minecraft:dirt", 2), layer("minecraft:grass_block", 1)], 10),
    "structure_overrides": LST([], 10)})})
dims = C({
    "minecraft:overworld": C({"type": S("minecraft:overworld"), "generator": flat}),
    "minecraft:the_nether": C({"type": S("minecraft:the_nether"), "generator": C({
        "type": S("minecraft:noise"), "settings": S("minecraft:nether"),
        "biome_source": C({"type": S("minecraft:multi_noise"), "preset": S("minecraft:nether")})})}),
    "minecraft:the_end": C({"type": S("minecraft:the_end"), "generator": C({
        "type": S("minecraft:noise"), "settings": S("minecraft:end"),
        "biome_source": C({"type": S("minecraft:the_end")})})}),
})
data = C({
    "allowCommands": B(1), "BorderCenterX": (6, struct.pack(">d", 0.0)), "BorderCenterZ": (6, struct.pack(">d", 0.0)),
    "ClearWeatherTime": I(0), "DataVersion": I(3465), "DayTime": L(6000), "Difficulty": B(0),
    "DifficultyLocked": B(0), "GameType": I(1), "hardcore": B(0), "initialized": B(1),
    "LastPlayed": L(int(time.time() * 1000)), "LevelName": S("TEST"), "raining": B(0), "rainTime": I(0),
    "SpawnAngle": F(0.0), "SpawnX": I(0), "SpawnY": I(-60), "SpawnZ": I(0), "thundering": B(0),
    "thunderTime": I(0), "Time": L(0), "version": I(19133), "WasModded": B(1),
    "GameRules": C({"doDaylightCycle": S("false"), "doWeatherCycle": S("false"), "doMobSpawning": S("false"),
                    "commandBlockOutput": S("false"), "sendCommandFeedback": S("false")}),
    "Version": C({"Id": I(3465), "Name": S("1.20.1"), "Series": S("main"), "Snapshot": B(0)}),
    "DataPacks": C({"Enabled": LST([S("vanilla"), S("file/cosmicfx_test")], 8), "Disabled": LST([], 8)}),
    "WorldGenSettings": C({"seed": L(12345), "generate_features": B(0), "bonus_chest": B(0), "dimensions": dims}),
})
root = b"\x0a" + s("") + C({"Data": data})[1]

W = "TEST_world/TEST"
os.makedirs(W, exist_ok=True)
with gzip.GzipFile(os.path.join(W, "level.dat"), "wb", mtime=0) as f:
    f.write(root)

DP = os.path.join(W, "datapacks/cosmicfx_test")
os.makedirs(DP + "/data/cosmicfx_test/functions", exist_ok=True)
os.makedirs(DP + "/data/minecraft/tags/functions", exist_ok=True)
json.dump({"pack": {"pack_format": 15, "description": "Cosmic FX test panel"}}, open(DP + "/pack.mcmeta", "w"))
json.dump({"values": ["cosmicfx_test:load"]}, open(DP + "/data/minecraft/tags/functions/load.json", "w"))
json.dump({"values": ["cosmicfx_test:tick"]}, open(DP + "/data/minecraft/tags/functions/tick.json", "w"))
F_ = DP + "/data/cosmicfx_test/functions/"
open(F_ + "load.mcfunction", "w").write("scoreboard objectives add cfxbuilt dummy\n")
open(F_ + "tick.mcfunction", "w").write("execute unless score #built cfxbuilt matches 1 if entity @a run function cosmicfx_test:build\n")

effects = [("mind_flayer", "Mind Flayer", " 3"), ("ribbon_sphere", "Ribbon Sphere", ""), ("galaxy", "Galaxy", ""),
           ("black_hole", "Black Hole", ""), ("dna_helix", "DNA Helix", ""), ("tornado", "Tornado", ""),
           ("phoenix", "Phoenix", ""), ("portal", "Portal", ""), ("supernova", "Supernova", ""),
           ("aurora", "Aurora", ""), ("rune_circle", "Rune Circle", ""), ("world_tree", "World Tree", "")]
lines = ["gamerule doDaylightCycle false", "time set midnight", "weather clear"]
for i, (n, label, sc) in enumerate(effects + [("STOP", "STOP ALL", "")]):
    x = -12 + 2 * i
    cmd = "cosmicfx stopall" if n == "STOP" else "cosmicfx play %s 0 -60 30%s" % (n, sc)
    lines.append('setblock %d -60 6 minecraft:command_block[facing=up]{Command:"%s"}' % (x, cmd))
    lines.append("setblock %d -59 6 minecraft:%s[face=floor,facing=north]" % (x, "crimson_button" if n == "STOP" else "polished_blackstone_button"))
    lines.append("setblock %d -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{\"text\":\"%s\"}','\"\"','\"\"','\"\"']}}" % (x, label))
lines.append("scoreboard players set #built cfxbuilt 1")
lines.append('tellraw @a {"text":"[Cosmic FX] Панель готова: нажимай кнопки у себя за спиной/впереди (z=6). Эффекты играют на z=30. STOP ALL — остановить всё.","color":"light_purple"}')
open(F_ + "build.mcfunction", "w").write("\n".join(lines) + "\n")
print("world ok")
