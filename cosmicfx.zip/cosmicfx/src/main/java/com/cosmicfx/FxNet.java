package com.cosmicfx;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

public final class FxNet {
    private FxNet() {}
    public static final Identifier PLAY = new Identifier(CosmicFX.MODID, "play");
    public static final Identifier STOP = new Identifier(CosmicFX.MODID, "stop");

    public static void sendPlay(ServerWorld world, String name, Vec3d pos, float scale, float yawDeg) {
        for (ServerPlayerEntity p : PlayerLookup.world(world)) {
            PacketByteBuf b = PacketByteBufs.create();
            b.writeString(name);
            b.writeDouble(pos.x);
            b.writeDouble(pos.y);
            b.writeDouble(pos.z);
            b.writeFloat(scale);
            b.writeFloat(yawDeg);
            ServerPlayNetworking.send(p, PLAY, b);
        }
    }

    public static void sendStop(MinecraftServer server) {
        for (ServerPlayerEntity p : PlayerLookup.all(server)) {
            ServerPlayNetworking.send(p, STOP, PacketByteBufs.create());
        }
    }
}
