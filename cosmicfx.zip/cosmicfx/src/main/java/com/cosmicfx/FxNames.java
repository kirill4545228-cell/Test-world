package com.cosmicfx;

import java.util.List;

public final class FxNames {
    private FxNames() {}
    public static final List<String> ALL = List.of(
        "mind_flayer", "ribbon_sphere", "galaxy", "black_hole", "dna_helix", "tornado",
        "phoenix", "portal", "supernova", "aurora", "rune_circle", "world_tree");
}
