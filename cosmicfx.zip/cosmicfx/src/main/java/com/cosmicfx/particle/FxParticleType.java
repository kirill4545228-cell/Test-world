package com.cosmicfx.particle;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.particle.ParticleType;

public class FxParticleType extends ParticleType<FxParticleEffect> {
    private final Codec<FxParticleEffect> codec;

    public FxParticleType() {
        super(true, FxParticleEffect.FACTORY);
        this.codec = RecordCodecBuilder.create(i -> i.group(
            Codec.FLOAT.fieldOf("r").forGetter(e -> e.r),
            Codec.FLOAT.fieldOf("g").forGetter(e -> e.g),
            Codec.FLOAT.fieldOf("b").forGetter(e -> e.b),
            Codec.FLOAT.fieldOf("size").forGetter(e -> e.size),
            Codec.INT.fieldOf("life").forGetter(e -> e.life),
            Codec.FLOAT.fieldOf("spin").forGetter(e -> e.spin)
        ).apply(i, (r, g, b, size, life, spin) -> new FxParticleEffect(this, r, g, b, size, life, spin)));
    }

    @Override
    public Codec<FxParticleEffect> getCodec() {
        return codec;
    }
}
