package com.cosmicfx.particle;

import com.cosmicfx.CosmicFX;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** New particles: cosmicfx:glow, star, ring, shard, wisp (animated), spark. */
public final class ModParticles {
    private ModParticles() {}

    public static final List<FxParticleType> ALL = new ArrayList<>();

    public static final FxParticleType GLOW = reg("glow");
    public static final FxParticleType STAR = reg("star");
    public static final FxParticleType RING = reg("ring");
    public static final FxParticleType SHARD = reg("shard");
    public static final FxParticleType WISP = reg("wisp");
    public static final FxParticleType SPARK = reg("spark");

    private static FxParticleType reg(String name) {
        FxParticleType t = Registry.register(Registries.PARTICLE_TYPE, new Identifier(CosmicFX.MODID, name), new FxParticleType());
        ALL.add(t);
        return t;
    }

    public static void init() {}
}
