package com.cosmicfx.particle;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleType;
import net.minecraft.registry.Registries;

/** Particle parameters: colour, half-size, lifetime (ticks) and spin speed. */
public class FxParticleEffect implements ParticleEffect {
    public static final ParticleEffect.Factory<FxParticleEffect> FACTORY = new ParticleEffect.Factory<>() {
        @Override
        public FxParticleEffect read(ParticleType<FxParticleEffect> type, StringReader reader) throws CommandSyntaxException {
            reader.expect(' ');
            float r = reader.readFloat();
            reader.expect(' ');
            float g = reader.readFloat();
            reader.expect(' ');
            float b = reader.readFloat();
            reader.expect(' ');
            float size = reader.readFloat();
            reader.expect(' ');
            int life = reader.readInt();
            reader.expect(' ');
            float spin = reader.readFloat();
            return new FxParticleEffect(type, r, g, b, size, life, spin);
        }

        @Override
        public FxParticleEffect read(ParticleType<FxParticleEffect> type, PacketByteBuf buf) {
            return new FxParticleEffect(type, buf.readFloat(), buf.readFloat(), buf.readFloat(),
                buf.readFloat(), buf.readInt(), buf.readFloat());
        }
    };

    private final ParticleType<FxParticleEffect> type;
    public final float r, g, b, size, spin;
    public final int life;

    public FxParticleEffect(ParticleType<FxParticleEffect> type, float r, float g, float b, float size, int life, float spin) {
        this.type = type;
        this.r = r;
        this.g = g;
        this.b = b;
        this.size = size;
        this.life = life;
        this.spin = spin;
    }

    @Override
    public ParticleType<?> getType() {
        return type;
    }

    @Override
    public void write(PacketByteBuf buf) {
        buf.writeFloat(r);
        buf.writeFloat(g);
        buf.writeFloat(b);
        buf.writeFloat(size);
        buf.writeInt(life);
        buf.writeFloat(spin);
    }

    @Override
    public String asString() {
        return Registries.PARTICLE_TYPE.getId(type) + " " + r + " " + g + " " + b + " " + size + " " + life + " " + spin;
    }
}
