package com.cosmicfx;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.Vec3ArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

public final class FxCommand {
    private FxCommand() {}

    private static final SuggestionProvider<ServerCommandSource> NAMES =
        (ctx, builder) -> CommandSource.suggestMatching(FxNames.ALL, builder);

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(CommandManager.literal("cosmicfx")
            .requires(s -> s.hasPermissionLevel(2))
            .then(CommandManager.literal("list").executes(c -> {
                c.getSource().sendFeedback(() -> Text.literal("Effects: " + String.join(", ", FxNames.ALL)), false);
                return FxNames.ALL.size();
            }))
            .then(CommandManager.literal("stopall").executes(c -> {
                FxNet.sendStop(c.getSource().getServer());
                return 1;
            }))
            .then(CommandManager.literal("play")
                .then(CommandManager.argument("effect", StringArgumentType.word()).suggests(NAMES)
                    .executes(c -> play(c, c.getSource().getPosition(), 1f))
                    .then(CommandManager.argument("pos", Vec3ArgumentType.vec3())
                        .executes(c -> play(c, Vec3ArgumentType.getVec3(c, "pos"), 1f))
                        .then(CommandManager.argument("scale", FloatArgumentType.floatArg(0.1f, 20f))
                            .executes(c -> play(c, Vec3ArgumentType.getVec3(c, "pos"), FloatArgumentType.getFloat(c, "scale"))))))));
    }

    private static int play(CommandContext<ServerCommandSource> c, Vec3d pos, float scale) {
        String name = StringArgumentType.getString(c, "effect");
        ServerCommandSource src = c.getSource();
        if (!FxNames.ALL.contains(name)) {
            src.sendError(Text.literal("Unknown effect: " + name + " (try /cosmicfx list)"));
            return 0;
        }
        FxNet.sendPlay(src.getWorld(), name, pos, scale, src.getRotation().y);
        src.sendFeedback(() -> Text.literal("Playing " + name), false);
        return 1;
    }
}
