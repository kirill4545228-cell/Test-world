package com.cosmicfx.client.fx;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class EffectManager {
    private EffectManager() {}

    private static final List<Ctx> ACTIVE = new ArrayList<>();

    public static void start(String name, double x, double y, double z, float scale, float yawDeg) {
        Effect e = EffectRegistry.create(name);
        if (e == null) return;
        ACTIVE.add(new Ctx(e, x, y, z, scale, Math.toRadians(yawDeg) + e.yawOffset()));
    }

    public static void stopAll() { ACTIVE.clear(); }

    public static void tick(MinecraftClient mc) {
        if (mc.world == null) {
            ACTIVE.clear();
            return;
        }
        if (mc.isPaused()) return;
        Iterator<Ctx> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Ctx c = it.next();
            c.world = mc.world;
            c.effect.tick(c);
            c.age++;
            if (c.age >= c.effect.duration()) it.remove();
        }
    }
}
