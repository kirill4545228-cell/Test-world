package com.cosmicfx.client.fx;

import com.cosmicfx.particle.ModParticles;

import java.util.Random;

/** 16-block double helix with glowing rungs and energy pulses running up it. 700 ticks. */
public class DnaHelixFx extends Effect {
    @Override
    public int duration() { return 700; }

    @Override
    public void tick(Ctx c) {
        int a = c.age;
        Random r = c.rng;
        double h = 16 * M.easeOut(a / 160.0);
        double fade = 1 - M.smooth(630, 700, a);
        double rot = a * 0.07, R = 1.6;
        if (a > 640) h *= fade;
        if (h < 0.5) return;

        for (double s = 0; s < h; s += 0.14) {
            double ang = s * 1.1 + rot;
            c.g(R * Math.cos(ang), s, R * Math.sin(ang), 0, 0, 0, 0x40E8FF, 0.13, 3);
            c.g(R * Math.cos(ang + Math.PI), s, R * Math.sin(ang + Math.PI), 0, 0, 0, 0xFF45D0, 0.13, 3);
        }
        for (double s = 0.3; s < h; s += 0.8) {
            double ang = s * 1.1 + rot;
            double x1 = R * Math.cos(ang), z1 = R * Math.sin(ang);
            for (int j = 0; j <= 6; j++) {
                double t = j / 6.0;
                c.g(M.lerp(x1, -x1, t), s, M.lerp(z1, -z1, t), 0, 0, 0, M.mix(0x40E8FF, 0xFF45D0, t), 0.09, 3);
            }
        }
        for (int p = 0; p < 2; p++) {
            double py = ((a * 0.35 + p * h * 0.5) % h);
            double ang = py * 1.1 + rot;
            for (int side = 0; side < 2; side++) {
                double aa = ang + side * Math.PI;
                c.g(R * Math.cos(aa), py, R * Math.sin(aa), 0, 0, 0, 0xFFFFFF, 0.4, 3);
                c.p(ModParticles.STAR, R * Math.cos(aa), py, R * Math.sin(aa), 0, 0, 0, 0xCCF8FF, 0.6, 3, 0.1);
            }
        }
        if (a % 40 == 0 && a < 640) c.ringBurst(0, 0.1, 0, 60, 0.25, 30, 0x60F0FF, 0.14);
        for (int i = 0; i < 4; i++) {
            c.p(ModParticles.STAR, r.nextGaussian() * 2, h + r.nextDouble() * 2, r.nextGaussian() * 2,
                0, 0.04, 0, 0xFFFFFF, 0.2, 25, 0.05);
        }
    }
}
