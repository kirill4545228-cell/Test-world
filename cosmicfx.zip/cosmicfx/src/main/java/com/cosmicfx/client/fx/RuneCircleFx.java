package com.cosmicfx.client.fx;

import com.cosmicfx.particle.ModParticles;

import java.util.Random;

/** Ground magic circle: drawn rings, counter-rotating hexagram, runes, light pillars, energy orb, final sky beam. 700 ticks. */
public class RuneCircleFx extends Effect {
    private final Orb orb = new Orb(5L, 8, 16);

    @Override
    public int duration() { return 700; }

    @Override
    public void tick(Ctx c) {
        int a = c.age;
        Random r = c.rng;
        double fade = 1 - M.smooth(640, 700, a);
        double maxAng = Math.PI * 2 * Math.min(1, a / 130.0);
        double rot = a * 0.01;
        double gy = 0.15;

        double[] radii = {6.2, 5.6, 3.6};
        for (int ri = 0; ri < 3; ri++) {
            for (int i = 0; i < 140; i++) {
                double th = i / 140.0 * Math.PI * 2;
                if (th > maxAng) break;
                if (r.nextDouble() > fade) continue;
                double rr = radii[ri];
                double ang = ri == 1 ? th + rot * 2 : (ri == 2 ? th - rot * 3 : th);
                c.g(rr * Math.cos(ang), gy, rr * Math.sin(ang), 0, 0, 0, M.mix(0x60C8FF, 0xFFFFFF, ri * 0.25), 0.1, 3);
            }
        }
        if (a > 60) {
            double d2 = M.smooth(60, 180, a);
            for (int tri = 0; tri < 2; tri++) {
                double base = (tri == 0 ? rot : -rot) + tri * Math.PI / 3;
                for (int e = 0; e < 3; e++) {
                    double a0 = base + e * Math.PI * 2 / 3, a1 = base + (e + 1) * Math.PI * 2 / 3;
                    double x0 = 5 * Math.cos(a0), z0 = 5 * Math.sin(a0), x1 = 5 * Math.cos(a1), z1 = 5 * Math.sin(a1);
                    for (int j = 0; j < 30; j++) {
                        double t = j / 30.0;
                        if (t > d2 || r.nextDouble() > fade) continue;
                        c.g(M.lerp(x0, x1, t), gy, M.lerp(z0, z1, t), 0, 0, 0, tri == 0 ? 0x80D8FF : 0xC0A0FF, 0.1, 3);
                    }
                }
            }
        }
        if (a > 40) {
            for (int i = 0; i < 12; i++) {
                double th = i * Math.PI / 6 + a * 0.008;
                c.p(ModParticles.STAR, 5.9 * Math.cos(th), gy + 0.1, 5.9 * Math.sin(th), 0, 0, 0, 0xFFE8A0, 0.3 * fade, 3, 0);
            }
        }
        if (a > 150) {
            double hgt = 14 * M.smooth(150, 230, a) * fade;
            for (int k = 0; k < 6; k++) {
                double th = k * Math.PI / 3;
                double x = 5 * Math.cos(th), z = 5 * Math.sin(th);
                for (double y = 0; y < hgt; y += 0.35) {
                    double ox = 0.35 * Math.cos(y * 2 + a * 0.2 + k), oz = 0.35 * Math.sin(y * 2 + a * 0.2 + k);
                    c.g(x + ox, y, z + oz, 0, 0, 0, M.mix(0x60C8FF, 0xFFFFFF, y / 14), 0.14, 3);
                }
            }
        }
        if (a > 250 && a < 700) {
            double orbR = 1.4 * M.smooth(250, 320, a) * fade;
            if (orbR > 0.05) {
                c.g(0, 7, 0, 0, 0, 0, 0xFFFFFF, 0.6 * orbR, 2);
                c.g(0, 7, 0, 0, 0, 0, 0x80D0FF, 1.0 * orbR, 2);
                orb.emit(c, 0, 7, 0, orbR, 1, 0.8);
            }
            for (int i = 0; i < 6; i++) {
                double th = r.nextDouble() * Math.PI * 2;
                double x = 5 * Math.cos(th), z = 5 * Math.sin(th);
                int life = 40;
                c.g(x, gy, z, -x / life, (7 - gy) / life, -z / life, 0x90E0FF, 0.12, life);
            }
        }
        if (a >= 500 && a < 660) {
            for (double y = 0; y < 70; y += 0.7) {
                double ang = y * 0.3 + a * 0.3;
                c.g(0.9 * Math.cos(ang), y, 0.9 * Math.sin(ang), 0, 0, 0, 0xA0E8FF, 0.2, 3);
                c.g(r.nextGaussian() * 0.2, y, r.nextGaussian() * 0.2, 0, 0, 0, 0xFFFFFF, 0.3, 3);
            }
            if (a == 500 || (a - 500) % 25 == 0) c.ringBurst(0, 0.3, 0, 300, 0.8, 50, 0xFFFFFF, 0.15);
        }
    }
}
