package com.cosmicfx.client.fx;

import com.cosmicfx.particle.ModParticles;

import java.util.Random;

/** Star charges and destabilises, collapses, detonates in shells + shockwave rings, leaves a pulsar and a nebula. 900 ticks. */
public class SupernovaFx extends Effect {
    @Override
    public int duration() { return 900; }

    @Override
    public void tick(Ctx c) {
        int a = c.age;
        Random r = c.rng;
        double cy = 16;

        if (a < 300) {
            double q = a / 300.0;
            double size = 0.5 + q * 2.0 + 0.15 * Math.sin(a * 0.4);
            c.g(0, cy, 0, 0, 0, 0, M.mix(0xFFE08A, 0x9FC8FF, q), size, 2);
            c.g(0, cy, 0, 0, 0, 0, 0xFFFFFF, size * 0.5, 2);
            int ni = (int) (10 + q * 70);
            for (int i = 0; i < ni; i++) {
                double[] d = M.unit(r);
                double dist = 22 * (0.5 + 0.5 * r.nextDouble());
                int life = 26;
                c.g(d[0] * dist, cy + d[1] * dist, d[2] * dist, -d[0] * dist / life, -d[1] * dist / life, -d[2] * dist / life,
                    M.mix(0xFFB060, 0xA0C8FF, q), 0.14, life);
            }
            if (a % 4 == 0) {
                double[] d = M.unit(r);
                double len = 1.5 + q * 6;
                for (int s = 0; s < 12; s++) {
                    double t = 1.5 + s / 12.0 * len;
                    c.p(ModParticles.STAR, d[0] * t, cy + d[1] * t, d[2] * t, 0, 0, 0, 0xFFFFFF, 0.2, 3, 0);
                }
            }
        } else if (a < 330) {
            double q = (a - 300) / 30.0;
            c.g(0, cy, 0, 0, 0, 0, 0xFFFFFF, 2.5 * (1 - q) + 0.4, 2);
        }

        if (a == 330) {
            c.sphereBurst(0, cy, 0, 1800, 0.95, 90, 0xFFFFFF, 0x9FC8FF, 0.3);
            c.ringBurst(0, cy, 0, 600, 1.3, 80, 0xFFFFFF, 0.25);
            c.p(ModParticles.RING, 0, cy, 0, 0, 0, 0, 0xFFFFFF, 6, 16, 0);
        }
        if (a == 335) {
            for (int i = 0; i < 500; i++) {
                double th = i * Math.PI * 2 / 500;
                c.g(0, cy, 0, 0, Math.sin(th) * 1.2, Math.cos(th) * 1.2, 0xBFE4FF, 0.2, 70);
            }
        }
        if (a == 345) c.sphereBurst(0, cy, 0, 1500, 0.75, 100, 0xFFD080, 0xFF5030, 0.3);
        if (a == 365) c.sphereBurst(0, cy, 0, 1200, 0.55, 110, 0xB070FF, 0x40A0FF, 0.3);

        if (a >= 330) {
            double fade = 1 - M.smooth(800, 900, a);
            // remnant pulsar
            c.g(0, cy, 0, 0, 0, 0, 0xFFFFFF, 0.6 * (1 - M.smooth(330, 900, a)) + 0.15, 2);
            double ang = a * 0.15;
            for (int s = 0; s < 40; s++) {
                double d = s * 0.6;
                c.g(d * Math.cos(ang), cy, d * Math.sin(ang), 0, 0, 0, 0xBFE4FF, 0.14, 2);
                c.g(-d * Math.cos(ang), cy, -d * Math.sin(ang), 0, 0, 0, 0xBFE4FF, 0.14, 2);
            }
            if (a > 400) {
                for (int i = 0; i < (int) (6 * fade); i++) {
                    c.g(r.nextGaussian() * 0.1, cy, r.nextGaussian() * 0.1, 0, 0.8, 0, 0xA0D0FF, 0.15, 25);
                    c.g(r.nextGaussian() * 0.1, cy, r.nextGaussian() * 0.1, 0, -0.8, 0, 0xA0D0FF, 0.15, 25);
                }
            }
            for (int i = 0; i < (int) (40 * fade); i++) {
                double th = r.nextDouble() * Math.PI * 2;
                double x = 4 * Math.cos(th), z = 4 * Math.sin(th);
                c.g(x, cy - z * 0.3, z * 0.95, 0, 0, 0, 0xFFA050, 0.12, 3);
            }
            // nebula
            if (a > 340 && a < 800) {
                double spread = 5 + (a - 330) * 0.03;
                for (int i = 0; i < 20; i++) {
                    double hue = 0.55 + r.nextDouble() * 0.4;
                    c.p(ModParticles.WISP, r.nextGaussian() * spread, cy + r.nextGaussian() * spread * 0.6, r.nextGaussian() * spread,
                        r.nextGaussian() * 0.01, r.nextGaussian() * 0.01, r.nextGaussian() * 0.01, M.hsv(hue, 0.6, 1), 0.8, 40, 0.01);
                }
            }
        }
    }
}
