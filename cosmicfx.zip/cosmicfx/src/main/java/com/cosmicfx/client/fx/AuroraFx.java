package com.cosmicfx.client.fx;

import com.cosmicfx.particle.ModParticles;

import java.util.Random;

/** Four drifting curtains of northern lights high above the centre, with twinkling stars. 1000 ticks. */
public class AuroraFx extends Effect {
    @Override
    public int duration() { return 1000; }

    @Override
    public void tick(Ctx c) {
        int a = c.age;
        Random r = c.rng;
        double fade = M.smooth(0, 120, a) * (1 - M.smooth(880, 1000, a));
        for (int k = 0; k < 4; k++) {
            double zk = (k - 1.5) * 11;
            for (double x = -34; x <= 34; x += 1.4) {
                if (r.nextDouble() > fade) continue;
                double yb = 26 + 4 * Math.sin(x * 0.13 + a * 0.018 + k * 1.7) + 2 * Math.sin(x * 0.37 - a * 0.027 + k);
                double h = 8 + 4 * Math.sin(x * 0.21 + a * 0.04 + k * 2.3);
                double z = zk + 3.5 * Math.sin(x * 0.09 + a * 0.012 + k);
                for (int j = 0; j < 3; j++) {
                    double f = r.nextDouble();
                    int col = M.hsv(0.36 + 0.4 * f, 0.7, 1 - 0.55 * f);
                    c.g(x + r.nextGaussian() * 0.2, yb + f * h, z + r.nextGaussian() * 0.3, 0, 0.01, 0, col, 0.55 - 0.25 * f, 8);
                }
            }
        }
        for (int i = 0; i < 3; i++) {
            if (r.nextDouble() > fade) continue;
            c.p(ModParticles.STAR, (r.nextDouble() - 0.5) * 80, 20 + r.nextDouble() * 25, (r.nextDouble() - 0.5) * 70,
                0, 0, 0, M.mix(0xFFFFFF, 0xA0C0FF, r.nextDouble()), 0.2, 20, 0);
        }
    }
}
