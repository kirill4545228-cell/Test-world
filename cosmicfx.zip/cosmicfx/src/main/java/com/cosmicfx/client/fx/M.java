package com.cosmicfx.client.fx;

import net.minecraft.util.math.MathHelper;

import java.util.Random;

/** Small math toolbox for the particle shows. */
public final class M {
    private M() {}

    public static double clamp01(double v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

    public static double smooth(double e0, double e1, double x) {
        double t = clamp01((x - e0) / (e1 - e0));
        return t * t * (3 - 2 * t);
    }

    public static double lerp(double a, double b, double t) { return a + (b - a) * t; }

    public static double easeOut(double t) {
        t = clamp01(t);
        double u = 1 - t;
        return 1 - u * u * u;
    }

    public static int rgbf(double r, double g, double b) {
        return ((int) (clamp01(r) * 255) << 16) | ((int) (clamp01(g) * 255) << 8) | (int) (clamp01(b) * 255);
    }

    public static int mix(int a, int b, double t) {
        t = clamp01(t);
        int r = (int) lerp((a >> 16) & 255, (b >> 16) & 255, t);
        int g = (int) lerp((a >> 8) & 255, (b >> 8) & 255, t);
        int bl = (int) lerp(a & 255, b & 255, t);
        return (r << 16) | (g << 8) | bl;
    }

    public static int hsv(double h, double s, double v) {
        h = h - Math.floor(h);
        return MathHelper.hsvToRgb((float) h, (float) s, (float) v);
    }

    /** Uniform random unit vector. */
    public static double[] unit(Random r) {
        double z = r.nextDouble() * 2 - 1;
        double a = r.nextDouble() * Math.PI * 2;
        double s = Math.sqrt(1 - z * z);
        return new double[]{s * Math.cos(a), z, s * Math.sin(a)};
    }

    /** Rodrigues rotation of v around the unit axis k by angle a. */
    public static double[] rot(double vx, double vy, double vz, double kx, double ky, double kz, double a) {
        double c = Math.cos(a), s = Math.sin(a), d = (kx * vx + ky * vy + kz * vz) * (1 - c);
        return new double[]{
            vx * c + (ky * vz - kz * vy) * s + kx * d,
            vy * c + (kz * vx - kx * vz) * s + ky * d,
            vz * c + (kx * vy - ky * vx) * s + kz * d};
    }

    /** Fibonacci sphere point i of n (even distribution on a sphere). */
    public static double[] fib(int i, int n) {
        double y = 1 - 2.0 * (i + 0.5) / n;
        double rr = Math.sqrt(Math.max(0, 1 - y * y));
        double th = i * 2.399963229728653;
        return new double[]{rr * Math.cos(th), y, rr * Math.sin(th)};
    }
}
