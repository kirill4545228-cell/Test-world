package com.cosmicfx.client.fx;

import com.cosmicfx.particle.ModParticles;

import java.util.Random;

/** Giant funnel with debris and lightning bolts. 700 ticks. */
public class TornadoFx extends Effect {
    @Override
    public int duration() { return 700; }

    @Override
    public void tick(Ctx c) {
        int a = c.age;
        Random r = c.rng;
        double fade = 1 - M.smooth(620, 700, a);
        double H = 18 * M.easeOut(a / 150.0);
        if (H < 0.5) return;

        int n = (int) (140 * fade);
        for (int i = 0; i < n; i++) {
            double y = Math.pow(r.nextDouble(), 0.8) * H;
            double rad = (0.7 + y * 0.42) * (0.75 + 0.5 * r.nextDouble());
            double w = 0.34 - y * 0.009;
            double th = r.nextDouble() * Math.PI * 2;
            double s = 0.45 + 0.4 * r.nextDouble();
            int col = M.rgbf(s, s, s * 1.05);
            c.p(ModParticles.WISP, rad * Math.cos(th), y, rad * Math.sin(th),
                -Math.sin(th) * w * rad, 0.12, Math.cos(th) * w * rad, col, 0.35 + rad * 0.04, 12,
                (r.nextDouble() - 0.5) * 0.1);
        }
        int nd = (int) (18 * fade);
        for (int i = 0; i < nd; i++) {
            double y = r.nextDouble() * H * 0.7;
            double rad = 1 + y * 0.35 + r.nextDouble();
            double th = r.nextDouble() * Math.PI * 2;
            double w = 0.3 - y * 0.008;
            c.p(ModParticles.SHARD, rad * Math.cos(th), y, rad * Math.sin(th),
                -Math.sin(th) * w * rad, 0.15, Math.cos(th) * w * rad,
                M.mix(0x5A4028, 0x9A8060, r.nextDouble()), 0.12, 14, (r.nextDouble() - 0.5) * 0.4);
        }
        for (int i = 0; i < (int) (10 * fade); i++) {
            double rad = 3 + r.nextDouble() * 5, th = r.nextDouble() * Math.PI * 2;
            c.g(rad * Math.cos(th), 0.2, rad * Math.sin(th), -Math.sin(th) * 0.3 - Math.cos(th) * 0.05, 0.03,
                Math.cos(th) * 0.3 - Math.sin(th) * 0.05, 0xA89878, 0.3, 12);
        }
        if (a > 80 && a < 600 && r.nextInt(22) == 0) {
            double bx = r.nextDouble() * 10 - 5, bz = r.nextDouble() * 10 - 5;
            double ox = 0, oz = 0;
            int steps = 44;
            for (int i = 0; i <= steps; i++) {
                double t = i / (double) steps;
                ox += r.nextGaussian() * 0.35;
                oz += r.nextGaussian() * 0.35;
                double x = M.lerp(bx, 0, t) + ox * (1 - t), z = M.lerp(bz, 0, t) + oz * (1 - t);
                double y = M.lerp(H + 8, 0, t);
                c.p(ModParticles.SPARK, x, y, z, 0, 0, 0, 0xDDEEFF, 0.25, 5, 0);
                if (i % 3 == 0) c.g(x, y, z, 0, 0, 0, 0x88AAFF, 0.5, 4);
            }
            c.g(0, 0.5, 0, 0, 0, 0, 0xFFFFFF, 2.0, 6);
            c.sphereBurst(0, 0.5, 0, 40, 0.3, 14, 0xFFFFFF, 0x88AAFF, 0.12);
        }
    }
}
