package com.cosmicfx.client.fx;

import com.cosmicfx.particle.ModParticles;

import java.util.Random;

/** Accretion disk with Keplerian rotation, infalling streams, polar jets and a photon ring. 800 ticks. */
public class BlackHoleFx extends Effect {
    private static double[] tf(double x, double y, double z, double ct, double st, double cp, double sp) {
        double yy = y * ct - z * st, zz = y * st + z * ct;
        return new double[]{x * cp - zz * sp, yy, x * sp + zz * cp};
    }

    @Override
    public int duration() { return 800; }

    @Override
    public void tick(Ctx c) {
        int a = c.age;
        Random r = c.rng;
        double k = M.smooth(0, 120, a) * (1 - M.smooth(740, 800, a));
        double cy = 11;
        double tilt = 1.05, ct = Math.cos(tilt), st = Math.sin(tilt);
        double prec = a * 0.004, cp = Math.cos(prec), sp = Math.sin(prec);

        // accretion disk
        int n = (int) (130 * k);
        for (int i = 0; i < n; i++) {
            double rad = 2 + Math.pow(r.nextDouble(), 1.3) * 7.5;
            double th = r.nextDouble() * Math.PI * 2;
            double om = 0.9 / (rad * Math.sqrt(rad));
            double x = rad * Math.cos(th), z = rad * Math.sin(th), y = r.nextGaussian() * 0.06 * rad;
            double vx = -Math.sin(th) * om * rad - Math.cos(th) * 0.01;
            double vz = Math.cos(th) * om * rad - Math.sin(th) * 0.01;
            double[] p = tf(x, y, z, ct, st, cp, sp);
            double[] v = tf(vx, 0, vz, ct, st, cp, sp);
            double heat = Math.pow(1 - (rad - 2) / 7.5, 1.5);
            int col = M.mix(0xFF5A18, 0xD8EEFF, heat);
            int life = rad < 4 ? 5 : 9;
            c.p(ModParticles.GLOW, p[0], cy + p[1], p[2], v[0], v[1], v[2], col, 0.1 + 0.08 * heat, life, 0);
        }
        // infalling streams
        int ni = (int) (22 * k);
        for (int i = 0; i < ni; i++) {
            double[] d = M.unit(r);
            double dist = 22 * (0.5 + 0.5 * r.nextDouble());
            double sx = d[0] * dist, sy = d[1] * dist, sz = d[2] * dist;
            int life = 45;
            double tx = -d[2] * 0.12, tz = d[0] * 0.12;
            c.g(sx, cy + sy, sz, -sx / life + tx, -sy / life, -sz / life + tz,
                M.mix(0x8F7CFF, 0xFFFFFF, r.nextDouble()), 0.14, life);
        }
        // photon ring
        if (k > 0.05) {
            for (int i = 0; i < 40; i++) {
                double th = r.nextDouble() * Math.PI * 2;
                c.g(1.7 * Math.cos(th), cy + 1.7 * Math.sin(th), 0, 0, 0, 0, 0xFFE8C0, 0.11, 2);
            }
        }
        // jets
        if (a > 120) {
            double[] ax = tf(0, 1, 0, ct, st, cp, sp);
            for (int s = -1; s <= 1; s += 2) {
                for (int i = 0; i < (int) (8 * k); i++) {
                    double lat = r.nextGaussian() * 0.04;
                    double[] u = M.unit(r);
                    c.g(ax[0] * s * 1.5 + u[0] * 0.2, cy + ax[1] * s * 1.5 + u[1] * 0.2, ax[2] * s * 1.5 + u[2] * 0.2,
                        ax[0] * s * 0.7 + lat, ax[1] * s * 0.7 + lat, ax[2] * s * 0.7 + lat,
                        M.mix(0xA060FF, 0x60E0FF, r.nextDouble()), 0.15, 30);
                }
            }
        }
        if (a == c.dur() - 60) {
            c.ringBurst(0, cy, 0, 300, 0.8, 50, 0xFFFFFF, 0.2);
            c.sphereBurst(0, cy, 0, 600, 0.5, 50, 0xFFB060, 0x80A0FF, 0.2);
        }
    }
}
