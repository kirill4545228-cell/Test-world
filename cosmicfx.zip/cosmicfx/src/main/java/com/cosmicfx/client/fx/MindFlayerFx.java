package com.cosmicfx.client.fx;

import com.cosmicfx.particle.FxParticleType;
import com.cosmicfx.particle.ModParticles;

import java.util.Random;

/**
 * Point -> ribbon sphere -> sphere collapses into a mind flayer (illithid) -> psionic pulses + mind blast -> dissolve.
 * 900 ticks = 45 s. Use scale 3 for a giant version.
 */
public class MindFlayerFx extends Effect {
    private static final int DUR = 900;
    private final Orb orb = new Orb(42L, 16, 20);
    private final Orb halo = new Orb(99L, 6, 16);
    private final Figure fig = new Figure();

    @Override
    public int duration() { return DUR; }

    @Override
    public double yawOffset() { return Math.PI; } // faces the person who ran the command

    @Override
    public void tick(Ctx c) {
        final int a = c.age;
        final Random r = c.rng;
        final double cy = 1.4;
        final FxParticleType STAR = ModParticles.STAR;

        // 1) the point
        if (a < 270) {
            double pulse = 1 + 0.3 * Math.sin(a * 0.35);
            double grow = 0.25 + 0.9 * M.smooth(0, 220, a);
            c.g(0, cy, 0, 0, 0, 0, 0xFFFFFF, 0.28 * pulse * grow, 2);
            c.g(0, cy, 0, 0, 0, 0, 0xB070FF, 0.55 * pulse * grow, 2);
            if (a % 3 == 0) c.p(STAR, 0, cy, 0, 0, 0, 0, 0xE8C8FF, 0.9 * pulse * grow, 4, 0.08);
        }

        // 2) ribbons float around the point and form a sphere, then it contracts
        double R = 0, spd = 1;
        if (a >= 40 && a < 260) {
            R = 2.2 * M.easeOut((a - 40) / 220.0) * (1 + 0.03 * Math.sin(a * 0.1));
        } else if (a >= 260 && a < 420) {
            double q = (a - 260) / 160.0;
            R = 2.2 * (1 - 0.55 * M.smooth(0, 1, q));
            spd = 1 + q * 3;
        } else if (a >= 420 && a < 445) {
            double q = (a - 420) / 25.0;
            R = 0.99 * (1 - q);
            spd = 4 + q * 4;
        }
        if (R > 0.03) orb.emit(c, 0, cy, 0, R, spd, 1.0);
        if (a == 445) {
            c.g(0, cy, 0, 0, 0, 0, 0xFFFFFF, 1.6, 6);
            c.sphereBurst(0, cy, 0, 160, 0.2, 18, 0xFFFFFF, 0xC070FF, 0.12);
        }

        // 3) streams of energy flow from the sphere into the body points
        if (a >= 270 && a < 450) {
            double q = (a - 270) / 180.0;
            int n = (int) (6 + q * 60);
            double rr = Math.max(R, 0.3);
            for (int i = 0; i < n; i++) {
                Figure.Pt t = fig.sample(r, a);
                double[] d = M.unit(r);
                double sx = d[0] * rr, sy = cy + d[1] * rr, sz = d[2] * rr;
                int life = 18 + r.nextInt(8);
                c.p(ModParticles.GLOW, sx, sy, sz, (t.x - sx) / life, (t.y - sy) / life, (t.z - sz) / life,
                    t.rgb, 0.12, life, 0);
            }
        }

        // 4) the body itself
        if (a >= 330) {
            double mat = M.smooth(330, 450, a);
            double die = M.smooth(780, 890, a);
            int n = a >= 895 ? 0 : (int) (240 * mat * (1 - die * 0.8));
            for (int i = 0; i < n; i++) {
                Figure.Pt t = fig.sample(r, a);
                double vx = 0, vy = 0, vz = 0;
                int life = 7;
                if (a >= 760) {
                    double k = M.smooth(760, 880, a);
                    double dx = t.x, dy = t.y - 1.4, dz = t.z;
                    double l = Math.sqrt(dx * dx + dy * dy + dz * dz) + 1e-6;
                    double s = 0.02 + 0.1 * k * r.nextDouble();
                    vx = dx / l * s - dz / l * 0.03 * k;
                    vy = dy / l * s + 0.04 * k;
                    vz = dz / l * s + dx / l * 0.03 * k;
                    life = 12;
                }
                c.p(t.kind, t.x, t.y, t.z, vx, vy, vz, t.rgb, t.size, life, 0);
            }
        }

        // 5) glowing eyes and hands
        if (a >= 400 && a < 860) {
            double e = M.smooth(400, 440, a) * (1 - M.smooth(840, 860, a));
            double flick = 0.8 + 0.2 * Math.sin(a * 0.7);
            for (int s = -1; s <= 1; s += 2) {
                c.p(STAR, s * 0.12, 2.27, 0.30, 0, 0, 0, 0xFFF2A0, 0.30 * e * flick, 2, 0);
                c.g(s * 0.12, 2.27, 0.31, 0, 0, 0, 0xFFFFFF, 0.13 * e, 2);
                double hp = 0.8 + 0.2 * Math.sin(a * 0.25 + s);
                c.g(s * 0.38, 1.68, 0.84, 0, 0, 0, 0x80F0FF, 0.34 * e * hp, 2);
                c.g(s * 0.38, 1.68, 0.84, 0, 0, 0, 0xFFFFFF, 0.14 * e, 2);
                double ao = a * 0.2 + s * 2;
                c.g(s * 0.38 + Math.cos(ao) * 0.25, 1.68 + Math.sin(ao) * 0.25, 0.84, 0, 0, 0, 0xA0F8FF, 0.07, 3);
            }
        }

        // 6) orbiting psionic halo around the head + ground sigil + rising runes
        if (a >= 450 && a < 840) {
            double hr = 0.85 * M.smooth(450, 490, a) * (1 - M.smooth(800, 840, a));
            if (hr > 0.03) halo.emit(c, 0, 2.25, 0, hr, 1.5, 0.8);
        }
        if (a >= 430 && a < 840) {
            double k = M.smooth(430, 480, a) * (1 - M.smooth(800, 840, a));
            for (int i = 0; i < 20; i++) {
                if (r.nextDouble() > k) continue;
                double th = i * Math.PI * 2 / 20 + a * 0.03;
                c.g(Math.cos(th) * 1.7, 0.05, Math.sin(th) * 1.7, 0, 0, 0, 0xC050FF, 0.09, 3);
                double th2 = -i * Math.PI * 2 / 20 - a * 0.05;
                c.g(Math.cos(th2) * 1.2, 0.05, Math.sin(th2) * 1.2, 0, 0, 0, 0xFF60D8, 0.07, 3);
            }
            if (a % 4 == 0) {
                double th = r.nextDouble() * Math.PI * 2;
                c.p(STAR, Math.cos(th) * 1.3, 0.2, Math.sin(th) * 1.3, 0, 0.05, 0, 0xD090FF, 0.22, 40, 0.04);
            }
        }

        // 7) psionic pulses
        for (int k = 0; k < 5; k++) {
            if (a == 470 + 70 * k && a != 610) {
                c.ringBurst(0, 2.25, 0, 90, 0.3, 28, k % 2 == 0 ? 0xFF50E0 : 0x60E8FF, 0.1);
                c.ringBurst(0, 0.1, 0, 90, 0.35, 26, 0xB050FF, 0.1);
                c.p(ModParticles.RING, 0, 2.25, 0, 0, 0, 0, 0xFF90F0, 2.2, 14, 0);
            }
        }

        // 8) mind blast: eye beams + sphere shell
        if (a >= 600 && a < 640) {
            for (int s = -1; s <= 1; s += 2) {
                for (double z = 0.4; z < 9; z += 0.45) {
                    c.g(s * 0.12 + r.nextGaussian() * 0.04, 2.27 + r.nextGaussian() * 0.04, z, 0, 0, 0,
                        r.nextBoolean() ? 0xFFFFFF : 0xFF60E0, 0.14, 3);
                }
            }
        }
        if (a == 610) {
            c.sphereBurst(0, 2.0, 0, 800, 0.6, 30, 0xFF60E0, 0x70F0FF, 0.16);
            c.ringBurst(0, 0.1, 0, 220, 0.9, 30, 0xFFFFFF, 0.16);
            c.p(ModParticles.RING, 0, 2.0, 0, 0, 0, 0, 0xFFFFFF, 4.0, 14, 0);
        }

        // 9) finish
        if (a == DUR - 1) {
            c.sphereBurst(0, 1.5, 0, 450, 0.5, 40, 0xFFFFFF, 0xB050FF, 0.18);
        }
    }
}
