package com.cosmicfx.client.fx;

import com.cosmicfx.particle.ModParticles;

import java.util.Random;

/** A single point; ribbons of particles start flowing around it and form a sphere. */
public class RibbonSphereFx extends Effect {
    private final Orb orb = new Orb(7L, 14, 18);

    @Override
    public int duration() { return 520; }

    @Override
    public void tick(Ctx c) {
        int a = c.age;
        Random r = c.rng;
        double cy = 4.0;
        double pulse = 1 + 0.25 * Math.sin(a * 0.3);
        double g = 0.3 + 0.7 * M.smooth(0, 40, a);
        c.g(0, cy, 0, 0, 0, 0, 0xFFFFFF, 0.3 * pulse * g, 2);
        c.g(0, cy, 0, 0, 0, 0, 0x9A5CFF, 0.6 * pulse * g, 2);
        if (a % 2 == 0) c.p(ModParticles.STAR, 0, cy, 0, 0, 0, 0, 0xFFE0FF, 0.9 * pulse * g, 3, 0.1);

        double R = 0, spd = 1;
        if (a >= 40 && a < 160) {
            R = 3.2 * M.easeOut((a - 40) / 120.0);
        } else if (a >= 160 && a < 430) {
            R = 3.2 * (1 + 0.04 * Math.sin(a * 0.06));
            spd = 1 + M.smooth(300, 430, a) * 2;
        } else if (a >= 430 && a < 505) {
            R = 3.2 * (1 - M.smooth(430, 505, a));
            spd = 3 + M.smooth(430, 505, a) * 4;
        }
        if (R > 0.03) orb.emit(c, 0, cy, 0, R, spd, 1.0);

        if (a >= 160 && a < 430) {
            for (int i = 0; i < 3; i++) {
                double[] d = M.unit(r);
                c.g(d[0] * R, cy + d[1] * R, d[2] * R, d[0] * 0.03, d[1] * 0.03, d[2] * 0.03, 0xE0C0FF, 0.1, 12);
            }
        }
        if (a == 40) c.sphereBurst(0, cy, 0, 120, 0.12, 20, 0xFFFFFF, 0xB070FF, 0.12);
        if (a == 505) {
            c.sphereBurst(0, cy, 0, 420, 0.45, 30, 0xFFFFFF, 0xB070FF, 0.15);
            c.ringBurst(0, cy, 0, 100, 0.5, 25, 0xFFFFFF, 0.15);
        }
    }
}
