package com.cosmicfx.client;

import com.cosmicfx.particle.FxParticleEffect;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.MathHelper;

/** Self-lit tinted billboard with fade in/out, spin and sprite animation over its lifetime. */
public class FxParticle extends SpriteBillboardParticle {
    private final SpriteProvider sprites;
    private final float baseSize;
    private final float spin;

    protected FxParticle(ClientWorld world, double x, double y, double z, double vx, double vy, double vz,
                         FxParticleEffect e, SpriteProvider sprites) {
        super(world, x, y, z);
        this.sprites = sprites;
        this.velocityX = vx;
        this.velocityY = vy;
        this.velocityZ = vz;
        this.red = e.r;
        this.green = e.g;
        this.blue = e.b;
        this.maxAge = Math.max(1, e.life);
        this.baseSize = e.size;
        this.spin = e.spin;
        this.velocityMultiplier = 1.0f;
        this.gravityStrength = 0.0f;
        this.collidesWithWorld = false;
        this.alpha = this.maxAge >= 10 ? 0.0f : 1.0f;
        this.angle = world.random.nextFloat() * 6.2831855f;
        this.prevAngle = this.angle;
        this.setSpriteForAge(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.dead) {
            return;
        }
        this.prevAngle = this.angle;
        this.angle += this.spin;
        float f = (float) this.age / (float) this.maxAge;
        float in = this.maxAge >= 10 ? Math.min(1.0f, f / 0.08f) : 1.0f;
        float out = this.maxAge >= 5 ? Math.min(1.0f, (1.0f - f) / 0.45f) : 1.0f;
        this.alpha = MathHelper.clamp(Math.min(in, out), 0.0f, 1.0f);
        this.setSpriteForAge(this.sprites);
    }

    @Override
    public float getSize(float tickDelta) {
        float f = ((float) this.age + tickDelta) / (float) this.maxAge;
        float k = this.maxAge >= 10 ? Math.min(1.0f, f / 0.15f) : 1.0f;
        if (this.maxAge >= 5) {
            k *= 0.45f + 0.55f * Math.min(1.0f, (1.0f - f) / 0.5f);
        }
        return this.baseSize * Math.max(0.05f, k);
    }

    @Override
    public int getBrightness(float tint) {
        return 0xF000F0;
    }

    @Override
    public ParticleTextureSheet getType() {
        return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Factory implements ParticleFactory<FxParticleEffect> {
        private final SpriteProvider sprites;

        public Factory(SpriteProvider sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(FxParticleEffect e, ClientWorld world, double x, double y, double z,
                                       double vx, double vy, double vz) {
            return new FxParticle(world, x, y, z, vx, vy, vz, e, sprites);
        }
    }
}
