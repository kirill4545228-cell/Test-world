package com.cosmicfx.client.fx;

import com.cosmicfx.particle.ModParticles;

import java.util.Random;

/** 10-block vertical portal (faces +z at yaw 0): runes, swirling arms, suction and travelling rings. 600 ticks. */
public class PortalFx extends Effect {
    @Override
    public int duration() { return 600; }

    @Override
    public void tick(Ctx c) {
        int a = c.age;
        Random r = c.rng;
        double open = M.easeOut(a / 80.0) * (1 - M.smooth(530, 600, a));
        double R = 5 * open;
        double cy = 5.8;
        if (a == 40) c.sphereBurst(0, cy, 0, 150, 0.2, 25, 0xFFFFFF, 0x9060FF, 0.14);
        if (a == c.dur() - 1) {
            c.sphereBurst(0, cy, 0, 400, 0.5, 35, 0xFFFFFF, 0x8060FF, 0.17);
            return;
        }
        if (R < 0.05) return;

        for (int i = 0; i < (int) (100 * open); i++) {
            double th = r.nextDouble() * Math.PI * 2;
            double rr = R + r.nextGaussian() * 0.12;
            double hue = 0.72 + 0.15 * Math.sin(a * 0.05 + th * 2);
            c.g(rr * Math.cos(th), cy + rr * Math.sin(th), r.nextGaussian() * 0.1, 0, 0, 0, M.hsv(hue, 0.7, 1), 0.22, 3);
        }
        for (int i = 0; i < 20; i++) {
            double th = i * Math.PI * 2 / 20 + a * 0.012;
            double rr = R + 0.9;
            c.p(ModParticles.STAR, rr * Math.cos(th), cy + rr * Math.sin(th), 0, 0, 0, 0, 0xC8A0FF, 0.35 * open, 3, 0);
        }
        for (int arm = 0; arm < 3; arm++) {
            for (int j = 0; j < 28; j++) {
                double rad = R * (j + r.nextDouble()) / 28.0;
                double th = rad * 1.1 - a * 0.15 + arm * 2.094;
                c.g(rad * Math.cos(th), cy + rad * Math.sin(th), r.nextGaussian() * 0.05, 0, 0, 0,
                    M.mix(0x6A20FF, 0xFFFFFF, 1 - rad / R), 0.18, 3);
            }
        }
        c.g(0, cy, 0, 0, 0, 0, 0xD8B8FF, 1.0 * open * (1 + 0.1 * Math.sin(a * 0.2)), 2);
        for (int i = 0; i < 10; i++) {
            double x = r.nextGaussian() * R * 0.7, y = r.nextGaussian() * R * 0.7;
            double z = (r.nextBoolean() ? 1 : -1) * (6 + r.nextDouble() * 8);
            int life = 25;
            c.g(x, cy + y, z, -x * 0.03, -y * 0.03, -z / life, 0xA070FF, 0.15, life);
        }
        if (a > 80 && a % 30 == 0) {
            for (int s = -1; s <= 1; s += 2) {
                for (int i = 0; i < 50; i++) {
                    double th = i * Math.PI * 2 / 50;
                    c.g(R * Math.cos(th), cy + R * Math.sin(th), 0, 0, 0, s * 0.25, 0x60E8FF, 0.14, 24);
                }
            }
        }
    }
}
