package com.cosmicfx.client.fx;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

public final class EffectRegistry {
    private EffectRegistry() {}

    private static final Map<String, Supplier<Effect>> MAP = new LinkedHashMap<>();

    static {
        MAP.put("mind_flayer", MindFlayerFx::new);
        MAP.put("ribbon_sphere", RibbonSphereFx::new);
        MAP.put("galaxy", GalaxyFx::new);
        MAP.put("black_hole", BlackHoleFx::new);
        MAP.put("dna_helix", DnaHelixFx::new);
        MAP.put("tornado", TornadoFx::new);
        MAP.put("phoenix", PhoenixFx::new);
        MAP.put("portal", PortalFx::new);
        MAP.put("supernova", SupernovaFx::new);
        MAP.put("aurora", AuroraFx::new);
        MAP.put("rune_circle", RuneCircleFx::new);
        MAP.put("world_tree", WorldTreeFx::new);
    }

    public static Effect create(String name) {
        Supplier<Effect> s = MAP.get(name);
        return s == null ? null : s.get();
    }
}
