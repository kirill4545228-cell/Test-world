package com.cosmicfx.client.fx;

import com.cosmicfx.particle.ModParticles;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** A fractal glowing tree grows branch by branch (~20 blocks), sap pulses climb it, leaves bloom and petals fall. 1200 ticks. */
public class WorldTreeFx extends Effect {
    private static final class Seg {
        double x0, y0, z0, x1, y1, z1;
        int t0, dur, depth;
        boolean tip;
    }

    private final List<Seg> segs = new ArrayList<>();

    public WorldTreeFx() {
        grow(new Random(2024), 0, 0, 0, 0, 1, 0, 6.5, 0, 0);
    }

    private void grow(Random r, double x, double y, double z, double dx, double dy, double dz, double len, int depth, int t) {
        Seg s = new Seg();
        s.x0 = x;
        s.y0 = y;
        s.z0 = z;
        s.x1 = x + dx * len;
        s.y1 = y + dy * len;
        s.z1 = z + dz * len;
        s.t0 = t;
        s.dur = (int) (30 + len * 20);
        s.depth = depth;
        segs.add(s);
        if (depth >= 7) {
            s.tip = true;
            return;
        }
        int kids = depth < 1 ? 3 : 2;
        for (int i = 0; i < kids; i++) {
            double[] u = M.unit(r);
            double kx = dy * u[2] - dz * u[1], ky = dz * u[0] - dx * u[2], kz = dx * u[1] - dy * u[0];
            double kl = Math.sqrt(kx * kx + ky * ky + kz * kz);
            if (kl < 1e-4) {
                kx = 1;
                ky = 0;
                kz = 0;
                kl = 1;
            }
            double ang = 0.35 + 0.35 * r.nextDouble();
            double[] nd = M.rot(dx, dy, dz, kx / kl, ky / kl, kz / kl, ang);
            nd[1] += 0.25;
            double nl = Math.sqrt(nd[0] * nd[0] + nd[1] * nd[1] + nd[2] * nd[2]);
            grow(r, s.x1, s.y1, s.z1, nd[0] / nl, nd[1] / nl, nd[2] / nl, len * 0.74, depth + 1, t + s.dur - 5);
        }
    }

    @Override
    public int duration() { return 1200; }

    @Override
    public void tick(Ctx c) {
        int a = c.age;
        Random r = c.rng;
        double fade = 1 - M.smooth(1100, 1200, a);
        if (a == c.dur() - 1) {
            c.sphereBurst(0, 16, 0, 300, 0.4, 40, 0xFFD27A, 0x7FFFE0, 0.2);
            return;
        }
        for (Seg s : segs) {
            if (a < s.t0) continue;
            double f = Math.min(1.0, (a - s.t0) / (double) s.dur);
            int cnt = s.depth <= 1 ? 6 : (s.depth <= 3 ? 3 : (s.depth <= 5 ? 2 : 1));
            double thick = 0.18 * Math.pow(0.7, s.depth);
            for (int i = 0; i < cnt; i++) {
                if (r.nextDouble() > fade) continue;
                double t = r.nextDouble() * f;
                c.g(M.lerp(s.x0, s.x1, t) + r.nextGaussian() * thick, M.lerp(s.y0, s.y1, t) + r.nextGaussian() * thick,
                    M.lerp(s.z0, s.z1, t) + r.nextGaussian() * thick,
                    0, 0, 0, M.mix(0x8A5A2B, 0xFFD27A, r.nextDouble() * 0.7), 0.14 * (1 - 0.07 * s.depth) + 0.05, 6);
            }
            if (s.depth <= 3) {
                double ph = ((a * 0.02 + s.depth * 0.3 + s.t0 * 0.0017) % 1.0) * f;
                c.g(M.lerp(s.x0, s.x1, ph), M.lerp(s.y0, s.y1, ph), M.lerp(s.z0, s.z1, ph), 0, 0, 0, 0x7FFFE0, 0.3, 3);
            }
            if (s.tip && f >= 1.0) {
                double b = M.smooth(0, 120, a - (s.t0 + s.dur)) * fade;
                if (r.nextDouble() < 0.5 * b) {
                    c.g(s.x1 + r.nextGaussian() * 0.6, s.y1 + r.nextGaussian() * 0.5, s.z1 + r.nextGaussian() * 0.6,
                        0, 0, 0, M.hsv(0.38 + r.nextDouble() * 0.12, 0.6, 1), 0.2, 14);
                }
                if (r.nextDouble() < 0.04 * b) {
                    c.p(ModParticles.STAR, s.x1 + r.nextGaussian() * 0.4, s.y1, s.z1 + r.nextGaussian() * 0.4,
                        0.02, -0.04, 0.01, 0xFFB0E0, 0.14, 70, 0.05);
                }
            }
        }
        if (a % 60 == 0 && a > 0 && a < 1100) c.ringBurst(0, 0.2, 0, 40, 0.15, 30, 0xFFD27A, 0.1);
    }
}
