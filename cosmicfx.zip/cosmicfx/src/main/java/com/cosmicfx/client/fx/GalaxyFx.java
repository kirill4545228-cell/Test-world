package com.cosmicfx.client.fx;

import com.cosmicfx.particle.FxParticleType;
import com.cosmicfx.particle.ModParticles;

import java.util.Random;

/** Spiral galaxy with 4 arms, glowing bulge and twinkling stars. 800 ticks. */
public class GalaxyFx extends Effect {
    @Override
    public int duration() { return 800; }

    @Override
    public void tick(Ctx c) {
        int a = c.age;
        Random r = c.rng;
        double grow = M.easeOut(a / 220.0);
        double fade = 1 - M.smooth(700, 800, a);
        double R = 14 * grow;
        double tilt = 0.5 + 0.15 * Math.sin(a * 0.006);
        double ct = Math.cos(tilt), st = Math.sin(tilt);
        double cy = 14;

        int n = (int) (90 * fade * Math.min(1, 0.2 + grow));
        for (int i = 0; i < n; i++) {
            int arm = r.nextInt(4);
            double q = Math.pow(r.nextDouble(), 0.65);
            double rad = 0.8 + q * R;
            double th = arm * Math.PI / 2 + rad * 0.5 + a * 0.02 + r.nextGaussian() * (0.12 + 0.25 * q);
            double x = rad * Math.cos(th), z = rad * Math.sin(th);
            double y = r.nextGaussian() * 0.35 * (1 - q * 0.7);
            double vx = -Math.sin(th) * 0.02 * rad, vz = Math.cos(th) * 0.02 * rad;
            double yy = y * ct - z * st, zz = y * st + z * ct;
            double vyy = -vz * st, vzz = vz * ct;
            int col = q < 0.35 ? M.mix(0xFFD890, 0xFFFFFF, q / 0.35)
                : M.mix(0xFFFFFF, r.nextDouble() < 0.3 ? 0xFF8AD8 : 0x6A8CFF, (q - 0.35) / 0.65);
            boolean star = r.nextDouble() < 0.12;
            FxParticleType k = star ? ModParticles.STAR : ModParticles.GLOW;
            c.p(k, x, cy + yy, zz, vx, vyy, vzz, col, 0.1 + r.nextDouble() * 0.15, 16, star ? 0.03 : 0);
        }
        // bulge
        int nb = (int) (30 * fade * grow);
        for (int i = 0; i < nb; i++) {
            c.g(r.nextGaussian() * 1.6, cy + r.nextGaussian() * 1.0, r.nextGaussian() * 1.6,
                0, 0, 0, 0xFFE0A0, 0.35, 10);
        }
        // core
        c.g(0, cy, 0, 0, 0, 0, 0xFFFFFF, 1.2 * (1 + 0.1 * Math.sin(a * 0.2)) * grow * fade, 2);
        // supernova flashes
        if (a > 100 && a % 90 == 45) {
            double rad = 3 + r.nextDouble() * 9, th = r.nextDouble() * 6.28;
            double x = rad * Math.cos(th), z = rad * Math.sin(th);
            c.sphereBurst(x, cy + (-z * st), z * ct, 40, 0.15, 20, 0xFFFFFF, 0x80B0FF, 0.15);
        }
    }
}
