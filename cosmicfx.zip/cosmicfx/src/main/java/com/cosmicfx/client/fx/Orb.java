package com.cosmicfx.client.fx;

import java.util.Random;

/** Sphere made of flowing particle ribbons: each ribbon is a head moving along a tilted circle with a fading tail. */
public final class Orb {
    private final int n, k;
    private final double[][] ax, u;
    private final double[] w, len, hue;
    private double phase;

    public Orb(long seed, int n, int k) {
        this.n = n;
        this.k = k;
        Random r = new Random(seed);
        ax = new double[n][];
        u = new double[n][];
        w = new double[n];
        len = new double[n];
        hue = new double[n];
        for (int i = 0; i < n; i++) {
            ax[i] = M.unit(r);
            double[] v = M.unit(r);
            double d = v[0] * ax[i][0] + v[1] * ax[i][1] + v[2] * ax[i][2];
            double ux = v[0] - ax[i][0] * d, uy = v[1] - ax[i][1] * d, uz = v[2] - ax[i][2] * d;
            double l = Math.sqrt(ux * ux + uy * uy + uz * uz) + 1e-9;
            u[i] = new double[]{ux / l, uy / l, uz / l};
            w[i] = (0.05 + r.nextDouble() * 0.06) * (r.nextBoolean() ? 1 : -1);
            len[i] = 1.2 + r.nextDouble() * 1.3;
            hue[i] = 0.55 + r.nextDouble() * 0.38;
        }
    }

    /** Call once per tick. speed advances the animation phase (1 = normal). */
    public void emit(Ctx c, double ox, double oy, double oz, double radius, double speed, double sizeMul) {
        phase += speed;
        double cp = Math.cos(phase * 0.01), sp = Math.sin(phase * 0.01);
        for (int i = 0; i < n; i++) {
            double sg = Math.signum(w[i]);
            for (int j = 0; j < k; j++) {
                double ang = w[i] * phase - sg * j * len[i] / k;
                double[] v = M.rot(u[i][0], u[i][1], u[i][2], ax[i][0], ax[i][1], ax[i][2], ang);
                double x = v[0] * cp - v[2] * sp, z = v[0] * sp + v[2] * cp, y = v[1];
                double rr = radius * (1 + 0.05 * Math.sin(phase * 0.08 + i * 1.3 + j * 0.45));
                double f = 1.0 - (double) j / k;
                int col = M.mix(M.hsv(hue[i], 0.65, 1.0), 0xFFFFFF, f * f * 0.8);
                c.g(ox + x * rr, oy + y * rr, oz + z * rr, 0, 0, 0, col, (0.07 + 0.16 * f) * sizeMul, 4);
            }
        }
    }
}
