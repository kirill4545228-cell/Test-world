package com.cosmicfx.client.fx;

import com.cosmicfx.particle.FxParticleEffect;
import com.cosmicfx.particle.FxParticleType;
import com.cosmicfx.particle.ModParticles;
import net.minecraft.client.world.ClientWorld;

import java.util.Random;

/** Running instance of an effect: position, scale, yaw and spawn helpers (all coordinates are local units). */
public final class Ctx {
    public ClientWorld world;
    public final Effect effect;
    public final double cx, cy, cz, scale, yaw;
    public int age;
    public final Random rng = new Random();
    private final double cs, sn, ss;

    public Ctx(Effect effect, double x, double y, double z, double scale, double yaw) {
        this.effect = effect;
        this.cx = x;
        this.cy = y;
        this.cz = z;
        this.scale = scale;
        this.yaw = yaw;
        this.cs = Math.cos(yaw);
        this.sn = Math.sin(yaw);
        this.ss = Math.sqrt(scale);
    }

    public int dur() { return effect.duration(); }

    /** Spawn one particle. Position/velocity are local (rotated by yaw, multiplied by scale). */
    public void p(FxParticleType t, double x, double y, double z, double vx, double vy, double vz,
                  int rgb, double size, int life, double spin) {
        if (world == null) return;
        double wx = x * cs - z * sn, wz = x * sn + z * cs;
        double wvx = vx * cs - vz * sn, wvz = vx * sn + vz * cs;
        FxParticleEffect e = new FxParticleEffect(t,
            ((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f,
            (float) (size * ss), life, (float) spin);
        world.addParticle(e, true, cx + wx * scale, cy + y * scale, cz + wz * scale, wvx * scale, vy * scale, wvz * scale);
    }

    public void g(double x, double y, double z, double vx, double vy, double vz, int rgb, double size, int life) {
        p(ModParticles.GLOW, x, y, z, vx, vy, vz, rgb, size, life, 0);
    }

    /** Uniform expanding spherical shell. */
    public void sphereBurst(double x, double y, double z, int n, double speed, int life, int c1, int c2, double size) {
        for (int i = 0; i < n; i++) {
            double[] d = M.fib(i, n);
            double sp = speed * (0.9 + 0.2 * rng.nextDouble());
            p(ModParticles.GLOW, x, y, z, d[0] * sp, d[1] * sp, d[2] * sp,
                M.mix(c1, c2, rng.nextDouble()), size, life + rng.nextInt(8), 0);
        }
    }

    /** Horizontal expanding ring. */
    public void ringBurst(double x, double y, double z, int n, double speed, int life, int rgb, double size) {
        for (int i = 0; i < n; i++) {
            double th = i * Math.PI * 2 / n;
            p(ModParticles.GLOW, x, y, z, Math.cos(th) * speed, 0, Math.sin(th) * speed, rgb, size, life, 0);
        }
    }
}
