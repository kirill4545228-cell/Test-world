package com.cosmicfx.client.fx;

import com.cosmicfx.particle.FxParticleType;
import com.cosmicfx.particle.ModParticles;

import java.util.Random;

/** Mind flayer as a procedural point cloud (local units, +z = front, ~2.7 tall). */
public final class Figure {
    public static final class Pt {
        public double x, y, z;
        public int rgb;
        public float size;
        public FxParticleType kind;
    }

    public Pt sample(Random r, int age) {
        Pt p = new Pt();
        p.kind = ModParticles.GLOW;
        p.size = 0.11f;
        double w = r.nextDouble() * 94;
        if (w < 38) {
            // robe: flared cone with slow folds
            double u = r.nextDouble();
            double th = r.nextDouble() * Math.PI * 2;
            double rad = (0.72 - 0.42 * u) * (1 + 0.07 * Math.sin(7 * th + age * 0.02));
            p.x = rad * Math.cos(th);
            p.z = rad * Math.sin(th) * 0.85;
            p.y = u * 1.75;
            p.rgb = M.mix(0x2A0A45, 0x7A35B0, u);
            if (u < 0.04) {
                p.rgb = 0xFF5CE0;
                p.kind = ModParticles.SPARK;
                p.size = 0.14f;
            }
        } else if (w < 56) {
            // bulbous head
            double[] d = M.unit(r);
            p.x = d[0] * 0.30;
            p.y = 2.2 + d[1] * 0.42;
            p.z = -0.04 + d[2] * 0.36;
            p.rgb = M.mix(0x9B59B6, 0xD7A8E8, (d[1] + 1) / 2);
            p.size = 0.10f;
        } else if (w < 76) {
            // four face tentacles, waving
            int k = r.nextInt(4);
            double s = r.nextDouble();
            double bx = (k - 1.5) * 0.11;
            p.x = bx * (1 + s * 1.2) + 0.09 * s * Math.sin(age * 0.12 + k * 1.7 + s * 5);
            p.y = 2.02 - s * 0.85;
            p.z = 0.27 + s * 0.2 + 0.12 * s * Math.sin(age * 0.1 + k * 2.1 + s * 4);
            p.rgb = M.mix(0xD070C0, 0xFFB0F0, s);
            p.size = (float) (0.12 - 0.05 * s);
        } else if (w < 86) {
            // tall collar behind the head
            double ang = (r.nextDouble() * 2 - 1) * 1.15;
            double s = r.nextDouble();
            double rr = 0.42 + s * 0.38;
            p.x = Math.sin(ang) * rr * 1.2;
            p.z = -Math.cos(ang) * (0.28 + s * 0.22) - 0.05;
            p.y = 1.7 + s * (0.95 - 0.3 * Math.abs(ang));
            p.rgb = M.mix(0x3B1060, 0xFF4DD2, s * s);
            p.size = 0.10f;
        } else {
            // raised casting arms
            double side = r.nextBoolean() ? 1 : -1;
            double t = r.nextDouble();
            double x, y, z;
            if (t < 0.5) {
                double q = t * 2;
                x = M.lerp(0.36, 0.60, q);
                y = M.lerp(1.70, 1.40, q);
                z = M.lerp(0.00, 0.38, q);
            } else {
                double q = (t - 0.5) * 2;
                x = M.lerp(0.60, 0.38, q);
                y = M.lerp(1.40, 1.70, q);
                z = M.lerp(0.38, 0.82, q);
            }
            double[] d = M.unit(r);
            double rad = 0.15 * (1 - 0.35 * t);
            p.x = side * (x + d[0] * rad);
            p.y = y + d[1] * rad;
            p.z = z + d[2] * rad;
            p.rgb = t > 0.92 ? 0x90F4FF : M.mix(0x3A1060, 0x8A45C8, 0.5);
        }
        return p;
    }
}
