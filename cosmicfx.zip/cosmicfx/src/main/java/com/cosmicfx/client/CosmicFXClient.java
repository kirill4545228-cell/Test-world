package com.cosmicfx.client;

import com.cosmicfx.FxNet;
import com.cosmicfx.client.fx.EffectManager;
import com.cosmicfx.particle.FxParticleType;
import com.cosmicfx.particle.ModParticles;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;

public class CosmicFXClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        for (FxParticleType t : ModParticles.ALL) {
            ParticleFactoryRegistry.getInstance().register(t, FxParticle.Factory::new);
        }

        ClientPlayNetworking.registerGlobalReceiver(FxNet.PLAY, (client, handler, buf, sender) -> {
            String name = buf.readString();
            double x = buf.readDouble();
            double y = buf.readDouble();
            double z = buf.readDouble();
            float scale = buf.readFloat();
            float yaw = buf.readFloat();
            client.execute(() -> EffectManager.start(name, x, y, z, scale, yaw));
        });
        ClientPlayNetworking.registerGlobalReceiver(FxNet.STOP,
            (client, handler, buf, sender) -> client.execute(EffectManager::stopAll));

        ClientTickEvents.END_CLIENT_TICK.register(EffectManager::tick);
    }
}
