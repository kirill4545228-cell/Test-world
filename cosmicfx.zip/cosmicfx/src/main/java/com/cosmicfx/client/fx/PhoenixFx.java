package com.cosmicfx.client.fx;

import com.cosmicfx.particle.FxParticleType;
import com.cosmicfx.particle.ModParticles;

import java.util.Random;

/** Fire phoenix flying in a circle with flapping wings, long tail and ember trail; ends by soaring up and bursting. 700 ticks. */
public class PhoenixFx extends Effect {
    private double px, py, pz, cf, sf;

    @Override
    public int duration() { return 700; }

    private void e(Ctx c, FxParticleType k, double lx, double ly, double lz, int rgb, double size, int life, double vy, double spin) {
        double wx = px + lx * cf - lz * sf, wz = pz + lx * sf + lz * cf;
        c.p(k, wx, py + ly, wz, 0, vy, 0, rgb, size, life, spin);
    }

    @Override
    public void tick(Ctx c) {
        int a = c.age;
        Random r = c.rng;
        double asc = M.smooth(540, 690, a);
        double phi = a * 0.03;
        double rad = 13 * (1 - 0.7 * asc);
        px = rad * Math.cos(phi);
        pz = rad * Math.sin(phi);
        py = 11 + 1.2 * Math.sin(a * 0.05) + asc * asc * 35;
        cf = Math.cos(phi);
        sf = Math.sin(phi);
        double fade = M.smooth(0, 30, a);
        if (a >= c.dur() - 1) {
            c.sphereBurst(px, py, pz, 500, 0.6, 50, 0xFFD040, 0xFF3000, 0.25);
            c.ringBurst(px, py, pz, 200, 0.8, 40, 0xFFE080, 0.2);
            return;
        }
        double flap = Math.sin(a * 0.2) * 0.7;

        // body
        for (int i = 0; i < 30; i++) {
            if (r.nextDouble() > fade) continue;
            double[] d = M.unit(r);
            e(c, ModParticles.GLOW, d[0] * 0.32, d[1] * 0.32, d[2] * 1.0, M.mix(0xFFD040, 0xFF5010, (d[2] + 1) / 2), 0.2, 3, 0, 0);
        }
        // head, beak, eyes, crest
        for (int i = 0; i < 8; i++) {
            double[] d = M.unit(r);
            e(c, ModParticles.GLOW, d[0] * 0.22, 0.28 + d[1] * 0.22, 1.25 + d[2] * 0.22, 0xFFE070, 0.14, 3, 0, 0);
        }
        for (int i = 0; i < 3; i++) {
            e(c, ModParticles.GLOW, 0, 0.25, 1.5 + r.nextDouble() * 0.3, 0xFF9020, 0.1, 3, 0, 0);
        }
        e(c, ModParticles.STAR, 0.1, 0.35, 1.38, 0xFFFFFF, 0.12, 3, 0, 0);
        e(c, ModParticles.STAR, -0.1, 0.35, 1.38, 0xFFFFFF, 0.12, 3, 0, 0);
        for (int k = 0; k < 3; k++) {
            double s = r.nextDouble();
            e(c, ModParticles.GLOW, (k - 1) * 0.08 * s, 0.5 + 0.3 * s, 1.2 - s * 0.9 + 0.1 * Math.sin(a * 0.2 + k), 0xFFB030, 0.1, 3, 0, 0);
        }

        // wings
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < 14; i++) {
                double q = i / 13.0;
                double beta = 0.1 + q * 1.0;
                double dirx = Math.cos(beta), dirz = -Math.sin(beta);
                double len = 5.0 - 2.6 * q;
                for (int j = 0; j < 10; j++) {
                    double s = (j + r.nextDouble()) / 10.0;
                    double alpha = flap * (0.3 + 1.0 * s);
                    double x = 0.3 + dirx * len * s;
                    double y = -0.6 * s * s;
                    double z = 0.6 + dirz * len * s;
                    double xr = x * Math.cos(alpha) - y * Math.sin(alpha);
                    double yr = x * Math.sin(alpha) + y * Math.cos(alpha);
                    int col = M.mix(0xFF3010, 0xFFD030, s * 0.8 + q * 0.2);
                    boolean st = r.nextDouble() < 0.06;
                    e(c, st ? ModParticles.STAR : ModParticles.GLOW, side * xr, yr, z, col, (0.2 - 0.08 * s) * (st ? 1.4 : 1), 3, 0, 0);
                    if (i == 0 && j == 9) {
                        for (int em = 0; em < 3; em++) {
                            e(c, ModParticles.GLOW, side * xr + r.nextGaussian() * 0.2, yr, z + r.nextGaussian() * 0.2,
                                0xFF8020, 0.15, 30, 0.03 + r.nextDouble() * 0.02, 0);
                        }
                    }
                }
            }
        }

        // tail feathers
        for (int k = 0; k < 5; k++) {
            for (int j = 0; j < 14; j++) {
                double s = j / 14.0;
                double lz = -0.9 - s * 5;
                double lx = (k - 2) * 0.35 * s + 0.4 * s * Math.sin(a * 0.12 - s * 4 + k);
                double ly = -0.1 - 0.4 * s * Math.sin(a * 0.1 + k - s * 3);
                e(c, ModParticles.GLOW, lx, ly, lz, M.mix(0xFFC030, 0xFF2000, s), 0.16 - 0.08 * s, 4, 0, 0);
            }
        }
        // aura + ember trail
        for (int i = 0; i < 4; i++) {
            e(c, ModParticles.GLOW, r.nextGaussian() * 0.8, r.nextGaussian() * 0.5, r.nextGaussian() * 0.8, 0xFF7010, 1.0, 5, 0, 0);
        }
        for (int i = 0; i < 6; i++) {
            e(c, ModParticles.GLOW, r.nextGaussian() * 0.5, r.nextGaussian() * 0.3, -1 - r.nextDouble() * 4, 0xFF9030, 0.14, 40, 0.02, 0);
        }
    }
}
