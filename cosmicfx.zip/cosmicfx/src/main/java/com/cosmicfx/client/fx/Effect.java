package com.cosmicfx.client.fx;

public abstract class Effect {
    /** Length of the show in ticks (20 ticks = 1 second). */
    public abstract int duration();

    /** Called once per client tick with ctx.age = 0 .. duration-1. */
    public abstract void tick(Ctx c);

    /** Extra rotation (radians) added to the yaw of the command source. */
    public double yawOffset() { return 0; }
}
