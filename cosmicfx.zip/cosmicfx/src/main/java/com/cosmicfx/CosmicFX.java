package com.cosmicfx;

import com.cosmicfx.particle.ModParticles;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

public class CosmicFX implements ModInitializer {
    public static final String MODID = "cosmicfx";

    @Override
    public void onInitialize() {
        ModParticles.init();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> FxCommand.register(dispatcher));
    }
}
