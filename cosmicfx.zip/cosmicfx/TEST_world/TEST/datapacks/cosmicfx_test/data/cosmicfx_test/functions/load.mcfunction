scoreboard objectives add cfxbuilt dummy
