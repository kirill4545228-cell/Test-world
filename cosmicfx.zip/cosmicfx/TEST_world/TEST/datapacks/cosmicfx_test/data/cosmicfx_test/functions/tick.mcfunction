execute unless score #built cfxbuilt matches 1 if entity @a run function cosmicfx_test:build
