gamerule doDaylightCycle false
time set midnight
weather clear
setblock -12 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx play mind_flayer 0 -60 30 3"}
setblock -12 -59 6 minecraft:polished_blackstone_button[face=floor,facing=north]
setblock -12 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"Mind Flayer"}','""','""','""']}}
setblock -10 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx play ribbon_sphere 0 -60 30"}
setblock -10 -59 6 minecraft:polished_blackstone_button[face=floor,facing=north]
setblock -10 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"Ribbon Sphere"}','""','""','""']}}
setblock -8 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx play galaxy 0 -60 30"}
setblock -8 -59 6 minecraft:polished_blackstone_button[face=floor,facing=north]
setblock -8 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"Galaxy"}','""','""','""']}}
setblock -6 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx play black_hole 0 -60 30"}
setblock -6 -59 6 minecraft:polished_blackstone_button[face=floor,facing=north]
setblock -6 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"Black Hole"}','""','""','""']}}
setblock -4 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx play dna_helix 0 -60 30"}
setblock -4 -59 6 minecraft:polished_blackstone_button[face=floor,facing=north]
setblock -4 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"DNA Helix"}','""','""','""']}}
setblock -2 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx play tornado 0 -60 30"}
setblock -2 -59 6 minecraft:polished_blackstone_button[face=floor,facing=north]
setblock -2 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"Tornado"}','""','""','""']}}
setblock 0 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx play phoenix 0 -60 30"}
setblock 0 -59 6 minecraft:polished_blackstone_button[face=floor,facing=north]
setblock 0 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"Phoenix"}','""','""','""']}}
setblock 2 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx play portal 0 -60 30"}
setblock 2 -59 6 minecraft:polished_blackstone_button[face=floor,facing=north]
setblock 2 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"Portal"}','""','""','""']}}
setblock 4 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx play supernova 0 -60 30"}
setblock 4 -59 6 minecraft:polished_blackstone_button[face=floor,facing=north]
setblock 4 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"Supernova"}','""','""','""']}}
setblock 6 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx play aurora 0 -60 30"}
setblock 6 -59 6 minecraft:polished_blackstone_button[face=floor,facing=north]
setblock 6 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"Aurora"}','""','""','""']}}
setblock 8 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx play rune_circle 0 -60 30"}
setblock 8 -59 6 minecraft:polished_blackstone_button[face=floor,facing=north]
setblock 8 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"Rune Circle"}','""','""','""']}}
setblock 10 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx play world_tree 0 -60 30"}
setblock 10 -59 6 minecraft:polished_blackstone_button[face=floor,facing=north]
setblock 10 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"World Tree"}','""','""','""']}}
setblock 12 -60 6 minecraft:command_block[facing=up]{Command:"cosmicfx stopall"}
setblock 12 -59 6 minecraft:crimson_button[face=floor,facing=north]
setblock 12 -60 5 minecraft:oak_wall_sign[facing=north]{is_waxed:1b,front_text:{messages:['{"text":"STOP ALL"}','""','""','""']}}
scoreboard players set #built cfxbuilt 1
tellraw @a {"text":"[Cosmic FX] Панель готова: нажимай кнопки у себя за спиной/впереди (z=6). Эффекты играют на z=30. STOP ALL — остановить всё.","color":"light_purple"}
